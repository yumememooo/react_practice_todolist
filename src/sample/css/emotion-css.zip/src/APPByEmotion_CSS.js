import { css } from "emotion";
export default function AppStyle() {}


export const myStyle = {
  BG: css`
    background-color: #3f51b5;
  `,
  BGTX: css`
    background-color: #3f51b5;
    color: red;
  `,
  SHOW: {
    COLOR: css`
      background-color: #3f51b5;
      color: red;
    `,
    SMALL: css`
      font-size: 8x;
    `
  },

  Input: {
    fullWidth: css`
      width: 100%;
    `
  }
};
