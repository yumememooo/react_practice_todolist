import React from "react";
import ReactDOM from "react-dom";

import APPByEmotion from "./APPByEmotion";
import AppBase from "./AppBase";

import AppByEmotionCore from "./AppByEmotionCore";
const rootElement = document.getElementById("root");
ReactDOM.render(
  <React.StrictMode>
    <div style={{display:'flex'}}>
    <AppBase/>

    <APPByEmotion/>
    <AppByEmotionCore />
    </div>
  </React.StrictMode>,
  rootElement
);
