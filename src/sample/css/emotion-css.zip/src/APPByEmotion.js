import React from "react";

import { css } from "emotion";

//定義在外部檔案
import { myStyle } from "./APPByEmotion_CSS";

export default function App() {
   //定義在內部
  const TextRed = css`
    color: red;
  `;

  return (
    <div className="App">

      <div>引入emotion庫 再用className套用</div>
      <h2 className={TextRed}>className</h2>
      <div>---引入外部js---</div>
      <h2 className={myStyle.SHOW.COLOR}>className</h2>
    </div>
  );
}
