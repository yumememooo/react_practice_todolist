import React from "react";
import "./styles.css";

export default function App() {


  return (
    <div className="App">
      {/*１．套用 styles.css檔樣式*/}
      <div>---１．套用 styles.css檔樣式---</div>
     
      <h2 className={["BG", "TextRed"].join(" ")}>外部CSS樣式表</h2>
      {/*多重套用className https://github.com/rtsao/csjs/wiki/How-to-apply-multiple-classnames-to-an-element */}
      <div>---２．套用 .Inline-style 樣式---</div>
<p>style={}</p>
      {/*２．套用 .Inline-style 樣式*/}
      <h2 style={{ color: "red", backgroundColor: "#3f51b5" }}>JS寫法</h2>

      </div>
  );
}
