import React from "react";

import {
  BG as ASBG,
  TextRed as ASTextRed,
  myStyle
} from "./AppByEmotionCore_CSS";

/** @jsx jsx */ import { css, jsx } from "@emotion/core"; //不知道為什麼一定要加前述

//練習用css-in-js庫emotion 更改樣式

export default function App() {
  const TextRed = css`
    color: red;
  `;

  const BG = css`
    background-color: #3f51b5;
  `;
  //https://stackoverflow.com/questions/61741076/css-emotion-library-getting-css-props-error-when-using-css-prop

  const Classes = css`
    color: purple;
    span {
      color: black;
    }
    & .childClassName {
      color: green;
    }
    & .otherChildClassName:hover {
      color: green;
    }
  `;

  const FO = css`
    &:focus {
      //這邊＆後面不能有空白喔
      background-color: #3f51b5;
    }
  `;

  return (
    <div className="App">
      <div>引入@emotion/core庫 再用css套用</div>
      <h2 css={TextRed}>emotion css 寫法</h2>
      <h2 css={[TextRed, BG]}>多重設定兩個樣式 [TextRed, BG]</h2>
      {/* <h2 className={Classes}> https://stackoverflow.com/questions/50840641/how-to-pass-multiple-classnames-to-inner-children-with-emotion-js*/}
      <h2 css={Classes}>
        emotion css ! 親樣式
        <span>子標籤</span>
        <div className="childClassName ">child 設定子樣式</div>
        <div className="otherChildClassName">child 有hover效果</div>
      </h2>

      <input type="text" css={FO} placeholder="輸入文字 focus效果" />

      <div>---引入外部js---</div>
      <h2 css={[ASBG, ASTextRed]}>AS多重命名</h2>
      <h2 css={myStyle.BGTX}>一層又一層clas.BGTX</h2>
      <h2 css={myStyle.SHOW.COLOR}>一層又一層定義clas.SHOW.COLOR</h2>
    </div>
  );
}
